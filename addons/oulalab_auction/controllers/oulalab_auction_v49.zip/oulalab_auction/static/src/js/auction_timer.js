/* OulaLab Auctions — timer, live polling y envío de ofertas.
   Vanilla JS registrado en web.assets_frontend. */
(function () {
    "use strict";

    // Odoo entrega datetimes como "YYYY-MM-DD HH:MM:SS" en UTC (naive).
    function parseOdooUTC(s) {
        if (!s) return null;
        return new Date(s.replace(" ", "T") + "Z");
    }

    // Llamada a una ruta type="jsonrpc" de Odoo.
    function jsonrpc(url, params) {
        return fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params: params || {},
                id: Math.floor(Math.random() * 1e9),
            }),
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.error) throw new Error(data.error.data && data.error.data.message || "Error");
                return data.result;
            });
    }

    function fmt(ms) {
        if (ms <= 0) return "Cerrada";
        var s = Math.floor(ms / 1000);
        var d = Math.floor(s / 86400); s -= d * 86400;
        var h = Math.floor(s / 3600); s -= h * 3600;
        var m = Math.floor(s / 60); s -= m * 60;
        var pad = function (n) { return String(n).padStart(2, "0"); };
        return (d > 0 ? d + "d " : "") + pad(h) + ":" + pad(m) + ":" + pad(s);
    }

    function initTimers() {
        document.querySelectorAll(".oulalab-timer").forEach(function (el) {
            var end = parseOdooUTC(el.dataset.end);
            var serverNow = parseOdooUTC(el.dataset.now);
            if (!end) return;
            // Offset entre reloj del cliente y del servidor (evita desfases).
            var offset = serverNow ? (serverNow.getTime() - Date.now()) : 0;
            var out = el.querySelector(".timer-value");

            function tick() {
                var remaining = end.getTime() - (Date.now() + offset);
                if (out) out.textContent = fmt(remaining);
                if (remaining <= 0) {
                    clearInterval(el._t);
                    var box = document.querySelector(".oulalab-bid-box");
                    if (box) box.innerHTML = '<div class="alert alert-secondary mb-0">La subasta ha cerrado.</div>';
                }
            }
            tick();
            el._t = setInterval(tick, 1000);
            el._end = end; el._offset = offset;
        });
    }

    function initDelivery(root, auctionId) {
        var box = root.querySelector(".oulalab-delivery-box");
        if (!box) return;
        var fields = box.querySelector(".oulalab-delivery-fields");
        var dbtn = box.querySelector(".oulalab-delivery-btn");
        var dfeedback = box.querySelector(".oulalab-delivery-feedback");

        // Mostrar/ocultar los campos de despacho según la modalidad elegida.
        box.querySelectorAll('input[name="delivmode"]').forEach(function (r) {
            r.addEventListener("change", function () {
                fields.style.display = (r.value === "delivery" && r.checked) ? "block" : "none";
            });
        });

        dbtn.addEventListener("click", function () {
            var checked = box.querySelector('input[name="delivmode"]:checked');
            dfeedback.textContent = "";
            if (!checked) { dfeedback.textContent = "Elige una modalidad de entrega."; return; }
            var rutEl = box.querySelector(".oulalab-rut");
            var payload = { mode: checked.value, rut: rutEl ? rutEl.value : "" };
            if (checked.value === "delivery") {
                payload.commune = box.querySelector(".oulalab-commune").value;
                payload.street = box.querySelector(".oulalab-street").value;
                payload.phone = box.querySelector(".oulalab-phone").value;
            }
            dbtn.disabled = true;
            jsonrpc("/auctions/delivery", payload)
                .then(function (res) {
                    dbtn.disabled = false;
                    if (res && res.ok) {
                        window.location.reload();   // recarga -> muestra el form de oferta
                    } else {
                        dfeedback.textContent = (res && res.error) || "No se pudo guardar.";
                    }
                })
                .catch(function (e) {
                    dbtn.disabled = false;
                    dfeedback.textContent = e.message || "Error de red.";
                });
        });
    }

    function initGuest(root) {
        var box = root.querySelector(".oulalab-guest-box");
        if (!box) return;
        var rutStep = box.querySelector(".oulalab-g-rutstep");
        var step1 = box.querySelector(".oulalab-g-step1");
        var step2 = box.querySelector(".oulalab-g-step2");
        var fb = box.querySelector(".oulalab-g-feedback");
        var fields = box.querySelector(".oulalab-g-fields");
        var rutValue = "";

        function val(sel) { var el = box.querySelector(sel); return el ? el.value.trim() : ""; }
        function setFb(msg) { fb.textContent = msg || ""; }
        function showCode(masked) {
            box.querySelector(".oulalab-g-sent-msg").textContent =
                "Tu correo ya está registrado. Enviamos un código de 6 dígitos a " + masked + ".";
            rutStep.style.display = "none";
            step1.style.display = "none";
            step2.style.display = "block";
        }

        box.querySelectorAll('input[name="gdelivmode"]').forEach(function (r) {
            r.addEventListener("change", function () {
                fields.style.display = (r.value === "delivery" && r.checked) ? "block" : "none";
            });
        });

        // Paso A: RUT -> ¿existe con correo registrado?
        box.querySelector(".oulalab-g-lookup").addEventListener("click", function (ev) {
            var btn = ev.currentTarget;
            setFb("");
            rutValue = val(".oulalab-g-rut-only");
            btn.disabled = true;
            jsonrpc("/auctions/guest/lookup", { rut: rutValue })
                .then(function (res) {
                    btn.disabled = false;
                    if (!res || !res.ok) { setFb((res && res.error) || "No se pudo continuar."); return; }
                    if (res.mode === "code") { showCode(res.masked); return; }
                    // RUT nuevo: pedir datos completos
                    box.querySelector(".oulalab-g-rut").value = rutValue;
                    box.querySelector(".oulalab-g-newnote").textContent =
                        "No encontramos tu RUT. Completa tus datos para continuar.";
                    rutStep.style.display = "none";
                    step1.style.display = "block";
                })
                .catch(function (e) { btn.disabled = false; setFb(e.message || "Error de red."); });
        });

        // Paso B: datos completos (RUT nuevo) -> envía código
        box.querySelector(".oulalab-g-send").addEventListener("click", function (ev) {
            var btn = ev.currentTarget;
            var checked = box.querySelector('input[name="gdelivmode"]:checked');
            setFb("");
            if (!checked) { setFb("Elige una modalidad de entrega."); return; }
            var payload = {
                rut: rutValue,
                name: val(".oulalab-g-name"), email: val(".oulalab-g-email"),
                phone: val(".oulalab-g-phone"), mode: checked.value,
            };
            if (checked.value === "delivery") {
                payload.commune = val(".oulalab-g-commune");
                payload.street = val(".oulalab-g-street");
            }
            btn.disabled = true;
            jsonrpc("/auctions/guest/start", payload)
                .then(function (res) {
                    btn.disabled = false;
                    if (res && res.ok) { showCode(res.masked); }
                    else { setFb((res && res.error) || "No se pudo enviar el código."); }
                })
                .catch(function (e) { btn.disabled = false; setFb(e.message || "Error de red."); });
        });

        // Paso C: código
        box.querySelector(".oulalab-g-verify").addEventListener("click", function (ev) {
            var btn = ev.currentTarget;
            setFb("");
            btn.disabled = true;
            jsonrpc("/auctions/guest/verify", { code: val(".oulalab-g-code") })
                .then(function (res) {
                    btn.disabled = false;
                    if (res && res.ok) { window.location.reload(); }
                    else { setFb((res && res.error) || "Código incorrecto."); }
                })
                .catch(function (e) { btn.disabled = false; setFb(e.message || "Error de red."); });
        });
    }

    function initPreviewLock(root) {
        var el = root.querySelector(".oulalab-lock-box");
        if (!el) return;
        var ms = Number(el.dataset.remainingMs || 0);
        if (ms > 0) {
            // Recarga al abrir la ventana pública (el servidor decide si ya puede subastar).
            setTimeout(function () { window.location.reload(); }, ms + 1000);
        }
    }

    function initDetail() {
        var root = document.querySelector(".oulalab-auction-detail");
        if (!root) return;
        var auctionId = root.dataset.auctionId;
        initDelivery(root, auctionId);
        initGuest(root);
        initPreviewLock(root);
        var btn = root.querySelector(".oulalab-bid-btn");
        var input = root.querySelector(".oulalab-bid-input");
        var feedback = root.querySelector(".oulalab-bid-feedback");
        var highestEl = root.querySelector(".oulalab-highest");
        var countEl = root.querySelector(".oulalab-bidcount");
        var minNextEl = root.querySelector(".oulalab-minnext");
        var timerEl = root.querySelector(".oulalab-timer");

        function applyState(res) {
            if (!res || !res.ok) return;
            if (highestEl) highestEl.textContent = highestEl.textContent.replace(/[\d.,]+/, Number(res.highest).toLocaleString("es-CL"));
            if (countEl) countEl.textContent = res.bid_count;
            if (minNextEl) minNextEl.textContent = minNextEl.textContent.replace(/[\d.,]+/, Number(res.min_next).toLocaleString("es-CL"));
            if (input) { input.min = res.min_next; input.dataset.min = res.min_next; }
            // Anti-sniping: el cierre puede haberse extendido.
            if (timerEl && res.end_date) {
                var newEnd = parseOdooUTC(res.end_date);
                if (newEnd) timerEl._end = newEnd;
            }
        }

        // Oferta
        if (btn) {
            btn.addEventListener("click", function () {
                var amount = parseFloat(input.value);
                var min = parseFloat(input.dataset.min);
                feedback.className = "oulalab-bid-feedback small mt-2";
                if (isNaN(amount) || amount < min) {
                    feedback.classList.add("text-danger");
                    feedback.textContent = "La oferta debe ser al menos " + Number(min).toLocaleString("es-CL");
                    return;
                }
                btn.disabled = true;
                jsonrpc("/auctions/" + auctionId + "/bid", { auction_id: Number(auctionId), amount: amount })
                    .then(function (res) {
                        btn.disabled = false;
                        if (res && res.ok) {
                            feedback.classList.add("text-success");
                            feedback.textContent = "¡Oferta registrada!";
                            applyState(Object.assign({ ok: true }, res));
                        } else {
                            feedback.classList.add("text-danger");
                            feedback.textContent = (res && res.error) || "No se pudo registrar la oferta.";
                        }
                    })
                    .catch(function (e) {
                        btn.disabled = false;
                        feedback.classList.add("text-danger");
                        feedback.textContent = e.message || "Error de red.";
                    });
            });
        }

        // Polling ligero cada 8s para reflejar ofertas de otros / extensiones.
        setInterval(function () {
            jsonrpc("/auctions/" + auctionId + "/state", { auction_id: Number(auctionId) })
                .then(applyState)
                .catch(function () {});
        }, 8000);
    }

    // El bloque de ingreso por RUT también vive en "Mis subastas", fuera del
    // detalle: ahí se inicializa con el documento como raíz.
    function initGuestStandalone() {
        if (document.querySelector(".oulalab-auction-detail")) return;
        if (document.querySelector(".oulalab-guest-box")) initGuest(document);
    }

    function boot() { initTimers(); initDetail(); initGuestStandalone(); }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
})();
